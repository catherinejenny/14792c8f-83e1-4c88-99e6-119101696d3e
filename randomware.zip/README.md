# NOT-Ransomware

A piece of ransomware written in C/C++ using the Windows API. 

Run `randomware.exe` this will start the program.

The executable does:

1. The code looks for a file named test.txt. 

2. It then creates a random key. 

3. This is used to RC4 encrypt the file. 

4. The key is then encrypted using the static RSA public key which is then stored on disk as ID followed by a snipped from the public key.

The code will not run if the two modules are not present. 